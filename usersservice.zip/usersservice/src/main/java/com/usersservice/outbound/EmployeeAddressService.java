package com.usersservice.outbound;

import com.usersservice.dto.EmployeeDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "address-api", url = "http://localhost:8082/address-api/v1")
public interface EmployeeAddressService {

    @RequestMapping(value = "/employees", method = RequestMethod.GET)
    public List<EmployeeDto> getAllEmployees(@RequestParam String id);

}
