package com.usersservice.controller;

import com.usersservice.dto.EmployeeDto;
import com.usersservice.dto.NumEmployeeDto;
import com.usersservice.model.EmployeeModel;
import com.usersservice.repository.EmployeeRepository;
import com.usersservice.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
@Slf4j
public class EmployeesController {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeService employeeService;

    @ResponseBody
    @PostMapping
    public String createEmployee(@RequestBody EmployeeDto employeeDto) {
        log.info("employee data received from uid {} ", employeeDto.getUid());
        EmployeeModel employee = new EmployeeModel(employeeDto.getUid(), employeeDto.getFirstName(), employeeDto.getLastName());
        employeeRepository.save(employee);
        log.info("employee saved successfully");

        return "success";
    }

    @ResponseBody
    @GetMapping("/{id}")
    public EmployeeDto createEmployee(@PathVariable String id) {
        log.info("fetch employee details from db uid =  {}", id);
        EmployeeModel employee = employeeRepository.getReferenceById(id);
        EmployeeDto employeeDto = new EmployeeDto(employee.getUid(), employee.getUid(), employee.getFirstName(), employee.getLastName(), null);

        return employeeDto;
    }

    @ResponseBody
    @PostMapping("/v1")
    public String createEmployee(@RequestBody NumEmployeeDto numEmployeeDto) {
        log.info("getNoEmployeeToBeCreated data received ", numEmployeeDto.getNoEmployeeToBeCreated());
        employeeService.bulkEmployeeUpdate(numEmployeeDto);
        log.info("update successsfully");

        return "success";
    }


}
