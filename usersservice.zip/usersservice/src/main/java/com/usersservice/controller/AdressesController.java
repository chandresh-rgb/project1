package com.usersservice.controller;

import com.usersservice.dto.EmployeeDto;
import com.usersservice.outbound.EmployeeAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/addresses")
public class AdressesController {

    @Autowired
    private EmployeeAddressService employeeAddressService;

    @GetMapping
    public List<EmployeeDto> getEmployees(@RequestParam String id) {
        List<EmployeeDto> employeeDtos = employeeAddressService.getAllEmployees(id);

        return employeeDtos;
    }

}
