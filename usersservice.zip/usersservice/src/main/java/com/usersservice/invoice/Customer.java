package com.usersservice.invoice;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    private Integer id;

    @Column(name = "customer_id", nullable = false)
    private String customerId;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    @Column(name = "vat_reg_number")
    private String vatRegNumber;

    @Column(name = "gst_number")
    private String gstNumber;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "website")
    private String website;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_address_id", referencedColumnName = "id")
    private CustomerAddress customerAddress;

    @Column(name = "agresso_code")
    private String agressoCode;

    @Column(name = "fusion_cust_acc_no")
    private String fusionCustomerAccountNumber;
}

