package com.usersservice.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Charge_Tax")
public class ChargeTax {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    private Integer id;

    @Column(name = "tax_type", nullable = false)
    private String type;

    @Column(name = "tax_percentage", nullable = false)
    private Integer percentage;

    @Column(name = "tax_value", nullable = false)
    private BigDecimal value;

    @Override
    public final boolean equals(Object o) {
        if (o == this)
            return true;

        if (!(o instanceof ChargeTax))
            return false;

        ChargeTax otherChargeTax = (ChargeTax) o;

        if (type.equalsIgnoreCase(otherChargeTax.getType()) && percentage == otherChargeTax.getPercentage()) {
            if ((value == null && otherChargeTax.getValue() == null) || (value == otherChargeTax.getValue()))
                return true;
        }

        return false;
    }

    @Override
    public final int hashCode() {
        return (this.getType() + " " + this.getPercentage()).hashCode();
    }
}
