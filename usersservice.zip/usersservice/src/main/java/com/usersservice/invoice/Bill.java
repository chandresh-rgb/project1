package com.usersservice.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Bill")
public class Bill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    private Integer id;

    @Column(name = "bill_uuid", nullable = false)
    private UUID uuid;

    @Column(name = "booking_id")
    private String bookingId;

    @Column(name = "service_code")
    private String serviceCode;

    @Column(name = "service_description")
    private String serviceDescription;

    @Column(name = "sac_code")
    private String sacCode;

    @Column(name = "unit_of_measurement")
    private String unitOfMeasurement;

    @Column(name = "units_consumed")
    private String unitsConsumed;

    @Column(name = "total_revenue")
    private BigDecimal totalRevenue;

    @Column(name = "total_tax")
    private BigDecimal totalTax;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    @Column(name = "terminal_code")
    private String terminalCode;

    @Column(name = "terminal_name")
    private String terminalName;

    @Column(name = "applicable_terminal_tariff")
    private String applicableTerminalTariff;

    @Column(name = "vessel_arrival_date")
    private LocalDateTime vesselArrivalDate;

    @Column(name = "vessel_departure_date")
    private LocalDateTime vesselDepartureDate;

    @Column(name = "vessel_name")
    private String vesselName;

    @Column(name = "vessel_code")
    private String vesselCode;

    @Column(name = "vessel_service_name")
    private String vesselServiceName;

    @Column(name = "base_currency")
    private String baseCurrency;

    @Transient
    @Column(name = "invoice_currency", insertable = false)
    private String invoiceCurrency;

    @Column(name = "exchange_rate")
    private BigDecimal exchangeRate;

    @Column(name = "container_from_date_time")
    private LocalDateTime containerFromDateTime;

    @Column(name = "container_to_date_time")
    private LocalDateTime containerToDateTime;

    @Column(name = "container_dwell_in_hours")
    private Integer containerDwellInHours;

    @Column(name = "container_free_days")
    private Integer containerFreeDays;

    @Column(name = "container_total_days")
    private Integer containerTotalDays;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "Bill_Charge_Mapping",
            joinColumns = @JoinColumn(name = "bill_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "charge_id", referencedColumnName = "id")
    )
    private Set<Charge> charges;
}


