package com.usersservice.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenerationTime;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Charge")
public class Charge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    private Integer id;

    @org.hibernate.annotations.Generated(value = GenerationTime.ALWAYS)
    @Column(name = "charge_uuid", nullable = false, insertable = false)
    private UUID uuid;

    @Column(name = "charge_type")
    private String chargeType;

    @Column(name = "charge_code")
    private String chargeCode;

    @Column(name = "charge_description")
    private String chargeDescription;

    @Column(name = "sac_code")
    private String sacCode;

    @Column(name = "total_revenue")
    private BigDecimal totalRevenue;

    @Column(name = "total_tax")
    private BigDecimal totalTax;

    @Column(name = "charge_total")
    private BigDecimal chargeTotal;

    @Column(name = "base_currency")
    private String baseCurrency;

    @Column(name = "terminal_code")
    private String terminalCode;

    @Transient
    @Column(name = "invoice_currency", insertable = false)
    private String invoiceCurrency;

    @Column(name = "exchange_rate")
    private BigDecimal exchangeRate;

    @Column(name = "financial_system_code")
    private String financialSystemCode;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "Charge_Tax_Charge_Mapping",
            joinColumns = @JoinColumn(name = "charge_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "tax_id", referencedColumnName = "id")
    )
    private Set<ChargeTax> taxes;

    @Override
    public final boolean equals(Object o) {
        if (o == this)
            return true;

        if (!(o instanceof Charge))
            return false;

        if (uuid != null && uuid == ((Charge) o).getUuid()) {
            return true;
        }

        return false;
    }

    @Override
    public final int hashCode() {
        return (uuid == null ? (0) : uuid).hashCode();
    }
}
