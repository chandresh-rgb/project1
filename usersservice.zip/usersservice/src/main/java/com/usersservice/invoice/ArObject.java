package com.usersservice.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenerationTime;
import org.springframework.data.annotation.LastModifiedBy;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "arobject")
public class ArObject {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    private Integer id;

    @org.hibernate.annotations.Generated(value = GenerationTime.ALWAYS)
    @Column(name = "arobject_uuid", nullable = false, insertable = false)
    private UUID uuid;

    @Column(name = "invoice_number")
    private String invoiceNumber;

    @Column(name = "tenant_uuid")
    private UUID tenantUUID;

    @Column(name = "booking_id")
    private String bookingId;

    @Column(name = "bco_name")
    private String bcoName;

    @Column(name = "bco_code")
    private String bcoCode;

    @Column(name = "shipment_creation_date")
    private LocalDateTime shipmentCreationDate;

    @Column(name = "tenant_specific_invoice_type")
    private String tenantSpecificInvoiceType;

    @Column(name = "tenant_specific_invoice_category")
    private String tenantSpecificInvoiceCategory;

    @Column(name = "invoice_currency")
    private String invoiceCurrency;

    @Column(name = "total_revenue")
    private BigDecimal totalRevenue;

    @Column(name = "total_tax")
    private BigDecimal totalTax;

    @Column(name = "total_invoice_amount")
    private BigDecimal totalInvoiceAmount;


    @Column(name = "invoice_date", nullable = false)
    @LastModifiedBy
    private LocalDateTime invoiceDate;

    @Column(name = "due_date")
    private LocalDateTime dueDate;

    @Column(name = "invoice_terms")
    private String invoiceTerms;

    @Column(name = "remittance_number")
    private String remittanceNumber;

    @Column(name = "integration_status")
    private String integrationStatus;

    @Column(name = "is_proforma", columnDefinition = "boolean default false")
    private Boolean isProforma = false;

    @Column(name = "credit_note_invoice_number")
    private String creditNoteInvoiceNumber;

    @Column(name = "note")
    private String note;

    @Column(name = "proforma_number")
    private String proformaNumber;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id", referencedColumnName = "id")
    private Customer customer;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "ArObject_Bill_Mapping",
            joinColumns = @JoinColumn(name = "arobject_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "bill_id", referencedColumnName = "id")
    )
    private Set<Bill> bills;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(name = "ArObject_Charge_Mapping",
            joinColumns = @JoinColumn(name = "arobject_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "Charge_id", referencedColumnName = "id")
    )
    private Set<Charge> charges;
}

