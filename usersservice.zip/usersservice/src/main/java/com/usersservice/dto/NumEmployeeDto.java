package com.usersservice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NumEmployeeDto implements Serializable {
    private Integer noEmployeeToBeCreated;
    private Integer bactchSize;

}
