package com.usersservice.service;

import com.usersservice.dto.NumEmployeeDto;
import com.usersservice.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
@Slf4j
public class EmployeeService {


    @Autowired
    private EmployeeRepository employeeRepository;


    public String bulkEmployeeUpdate(NumEmployeeDto employeeDto) {

        int numberOfCores = Runtime.getRuntime().availableProcessors();
        ExecutorService executorService = Executors.newFixedThreadPool(numberOfCores);
        log.info("number of cores in my machine {} ", numberOfCores);

        int batchSize = employeeDto.getNoEmployeeToBeCreated() / numberOfCores;

        for (int i = 0; i < numberOfCores; i++) {
            executorService.submit(new EmployeeUpdateCallble(batchSize, employeeRepository));
        }


        return "success";
    }

    public <T> Stream<List<T>> batches(List<T> source, int length) {
        if (length <= 0) throw new IllegalArgumentException("length = " + length);
        int size = source.size();
        if (size <= 0) return Stream.empty();
        int fullChunks = (size - 1) / length;
        return IntStream.range(0, fullChunks + 1).mapToObj(n -> source.subList(n * length, n == fullChunks ? size : (n + 1) * length));
    }
}
