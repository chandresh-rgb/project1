package com.usersservice.service;

import com.github.javafaker.Faker;
import com.usersservice.model.EmployeeModel;
import com.usersservice.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;


@Slf4j
public class EmployeeUpdateCallble implements Callable<Boolean> {

    int batchSize;

    EmployeeRepository repository;


    public EmployeeUpdateCallble(int batchSize, EmployeeRepository repository) {
        this.repository = repository;
        this.batchSize = batchSize;
    }

    @Override
    public Boolean call() throws Exception {
        List<EmployeeModel> employees = new ArrayList<>();
        for (int i = 0; i < batchSize; i++) {
            Faker faker = new Faker();
            EmployeeModel employee = new EmployeeModel("+91".concat(faker.number().digits(10)), faker.name().firstName(), faker.name().lastName());
            employees.add(employee);
        }

        repository.saveAll(employees);


        log.info("employees thread name {} ", Thread.currentThread().getName());


        return Boolean.TRUE;
    }
}
